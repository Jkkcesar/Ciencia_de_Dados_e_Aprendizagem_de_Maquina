# simulação_out_of_core_pandas.py
#
# Um pequeno script em Python simulando como faríamos se tivéssemos 
# que resolver isso usando ESTRITAMENTE só a máquina de 16GB (sem cluster).
# A lógica usa "Chunking" (processamento em blocos iterativos no Pandas).

import pandas as pd

def resolver_desafio_16gb_ram(caminho_arquivo):
    # Lendo 1 milhão de linhas por vez para não estourar a RAM
    tamanho_lote = 1_000_000 
    
    faturamento_total = 0
    total_transacoes = 0
    agrupamento_cidades = pd.Series(dtype=float)
    agrupamento_produtos = pd.Series(dtype=float)
    
    print("Iniciando processamento em lotes...")
    
    for chunk in pd.read_csv(caminho_arquivo, chunksize=tamanho_lote):
        
        # Incrementando o faturamento
        faturamento_total += chunk['valor'].sum()
        total_transacoes += len(chunk)
        
        # Agregações parciais
        agrupamento_cidades = agrupamento_cidades.add(chunk['cidade'].value_counts(), fill_value=0)
        agrupamento_produtos = agrupamento_produtos.add(chunk['produto'].value_counts(), fill_value=0)
        
    # Agregação Final (Reduce lógico)
    cidade_top = agrupamento_cidades.idxmax()
    produto_top = agrupamento_produtos.idxmax()
    valor_medio = faturamento_total / total_transacoes
    
    print("--- RESULTADOS FINAIS ---")
    print(f"1. Cidade que vende mais: {cidade_top}")
    print(f"2. Produto que vende mais: {produto_top}")
    print(f"3. Faturamento Total: R$ {faturamento_total:.2f}")
    print(f"4. Valor Médio: R$ {valor_medio:.2f}")

# Exemplo de uso:
# resolver_desafio_16gb_ram("dataset_5_bilhoes.csv")
