# Solução: O Desafio dos 5 Bilhões

## O Cenário
Uma empresa possui 5 bilhões de compras registradas e precisamos responder:
1. Qual cidade vende mais?
2. Qual produto vende mais?
3. Qual é o faturamento total?
4. Qual é o valor médio das compras?

**O Problema:** O computador disponível possui apenas **16 GB de RAM**. 

---

## Desenho da Solução (Atividade em Grupos)

Tentar carregar 5 bilhões de registros de uma única vez em uma máquina com 16GB de RAM causará travamento imediato por falta de memória (*Out of Memory*). A solução passa pela adoção de tecnologias de **Processamento Distribuído** (arquitetura MapReduce).

### 1. Uma máquina ou várias?
**Várias.** Trabalharemos com um cluster computacional. Uma máquina atua como o nó gerenciador (Master/Driver) e várias outras atuam como nós trabalhadores (Worker Nodes). 
*(Nota: Se fôssemos forçados pela restrição a usar apenas essa máquina de 16GB, teríamos que usar processamento "Out-of-Core", lendo os dados do disco rígido em pequenos lotes iterativos — chunks — sem estourar a memória, mas isso levaria um tempo impraticável. Um cluster é a resposta definitiva de Big Data).*

### 2. Como dividir os dados?
Através do **Particionamento**. Os dados (os 5 bilhões de registros) são fragmentados em blocos menores (ex: blocos de 128MB em um sistema de arquivos como HDFS) e distribuídos pelo disco de todos os Workers do cluster. A divisão pode ser feita por uma chave primária, data da venda ou simples particionamento sequencial.

### 3. O que cada máquina faria?
Cada máquina executará a etapa de **Map** da sua própria partição local simultaneamente:
- Leria os detalhes da compra de seu bloco.
- Contaria e agruparia as vendas por cidade e por produto localmente.
- Somaria o faturamento e a quantidade de transações daquela fatia específica.

### 4. Como juntar os resultados?
Através da etapa de **Reduce**. Após os cálculos locais, os Workers enviam (via *Shuffle* pela rede) os seus "subtotais" para um nó agregador (Reducer). O Reducer simplesmente soma todos os faturamentos parciais para chegar ao faturamento total, soma as quantidades para chegar ao total de transações (e então calcula a média final), e compara as contagens agrupadas para definir a cidade e o produto campeão.

---

### ⚠️ Desafio Extra: Uma das máquinas parou de funcionar. O que deveria acontecer?
**Tolerância a falhas.** Em um ecossistema Big Data distribuído, os dados nunca ficam em apenas um lugar; eles sofrem **replicação** (geralmente copiados em 3 nós diferentes). Se o nó Master parar de receber o sinal de rede (*heartbeat*) de uma máquina que pifou, ele redistribui imediatamente a tarefa que ela estava fazendo para outra máquina que possua a cópia (réplica) exata daquele mesmo bloco de dados, permitindo que a operação continue e termine com sucesso sem perda de dados.
