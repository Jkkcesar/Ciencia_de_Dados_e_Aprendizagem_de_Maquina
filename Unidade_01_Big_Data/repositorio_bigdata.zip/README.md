# Atividades de Big Data - Sistemas de Informação

Repositório criado para registrar a solução da atividade "O Desafio dos 5 Bilhões" e conceitos fundamentais de Big Data.

**Autor:** Júlio César De Aguiar Nunes  
**Curso:** Sistemas de Informação  
**Status:** Ano de TCC 🚀

---

## 📌 O que levamos da aula? (Finalização)

**1. Em 3 frases, explique o que é Big Data e por que ele é importante para Ciência de Dados e Machine Learning:**

O Big Data refere-se a conjuntos de dados tão gigantescos e complexos — guiados por características como Volume, Velocidade, Variedade, Veracidade e Valor — que as ferramentas tradicionais de processamento não dão conta de gerenciar. Para a Ciência de Dados, ele é o insumo bruto essencial que, quando processado em larga escala, permite a descoberta de padrões ocultos e a extração de insights avançados. Já no contexto de Machine Learning, essa abundância extrema de dados é o que garante o treinamento eficaz dos algoritmos, pois quanto maior e mais variada a base histórica, melhor será a capacidade do modelo de generalizar, aprender padrões complexos e realizar predições precisas.

**2. Abrir um repositório no GitHub para a disciplina e registrar a resposta.**
- *Check!* (Você está nele).

**Fontes de Pesquisa:**
- Conceitos acadêmicos da disciplina de Sistemas de Informação.
- MAYER-SCHÖNBERGER, V.; CUKIER, K. *Big Data: A Revolution That Will Transform How We Live, Work, and Think*. Houghton Mifflin Harcourt, 2013.
- Documentação de design de arquiteturas distribuídas (Apache Spark / Hadoop).
